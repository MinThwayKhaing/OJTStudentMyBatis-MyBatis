package myBatis.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import DTO.CourseStudentRequestDTO;
import DTO.CourseStudentResponseDTO;



@Service("courseStudentMyBatis")
public interface CourseStudent 
{
	String insertData="insert into course_student (student_id,course_name) values(#{studentid},#{course})";
	String deleteData="delete from course_student where student_id=#{studentid}";
	String search="select * from course_student where coursename=#{searchcourse}";
	String selectOne="select * from course_student where student_id=#{studentid}";
	String selectAll="select * from studenttable";
	
	
	@Delete(deleteData)
	int deleteData(CourseStudentRequestDTO dto);
	@Insert(insertData)
	int insertData(CourseStudentRequestDTO dto);
	
	@Select(selectOne)
	@Results(value = {
			
			@Result(column ="course_name", property="course"),
			
	})
	ArrayList<String> selectOne(String id);
	
	@Select(selectAll)
	@Results(value ={
			
			@Result(column ="course_name", property="course"),
			
	})
	ArrayList<CourseStudentRequestDTO> selectAll();
	
	@Select(search)
	@Results(value ={
		
			@Result(column ="course_name", property="course"),
		
	})
	List<CourseStudentResponseDTO> search(CourseStudentRequestDTO dto);
	
	
}
