package myBatis.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import DTO.UserRequestDTO;
import DTO.UserResponseDTO;
import Model.LoginBean;


public interface UserMyBatis 
{
	String Login="select * from usertable where userid=#{id} and password=#{password}";
	String insertData ="insert into usertable(userid,username,email,password,userrole)"+
			"values(#{userid},#{username},#{email},#{password},#{userrole})";
	String updateData="update usertable set username=#{username},email=#{email},password=#{password},userrole=#{userrole}"+"where userid=#{userid}";
	String deleteData="delete from usertable where userid=#{userid}";
	String selectOne="select * from usertable where userid=#{userid}";
	String search="select * from usertable where userid=#{searchid} or username=#{searchname}";
	String selectAll="select * from usertable";
	

	@Select(Login)
	@Results(value = {
			@Result(column ="userid", property="userid"),
			@Result(column ="username", property="username"),
	})
	ArrayList<UserResponseDTO> Login(LoginBean bean);
	
	
	@Insert(insertData)
	int insertData(UserRequestDTO dto);
	@Update(updateData)
	int updateData(UserRequestDTO dto);
	
	@Delete(deleteData)
	int deleteData(UserRequestDTO dto);
	
	@Select(selectAll)
	@Results(value ={
		@Result(column ="userid", property="userid"),
		@Result(column ="username", property="username"),
		@Result(column ="email", property="email"),
		@Result(column ="password", property="password"),
		@Result(column ="userrole", property="userrole"),
		
	})
	ArrayList<UserResponseDTO> selectAll();
	
	@Select(selectOne)
	@Results(value = {
			@Result(column ="userid", property="userid"),
			@Result(column ="username", property="username"),
			@Result(column ="email", property="email"),
			@Result(column ="password", property="password"),
			@Result(column ="userrole", property="userrole"),
	})
	UserResponseDTO selectOne(UserRequestDTO dto);
	
	@Select(search)
	@Results(value ={
		@Result(column ="userid", property="userid"),
		@Result(column ="username", property="username"),
		@Result(column ="email", property="email"),
		@Result(column ="password", property="password"),
		@Result(column ="userrole", property="userrole"),
		
	})
	List<UserResponseDTO> search(UserRequestDTO dto);
	
}
