package myBatis.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Service;

import DTO.StudentRequestDTO;
import DTO.StudentResponseDTO;
import DTO.UserRequestDTO;
import DTO.UserResponseDTO;

@Service("studentMyBatis")
public interface StudentMyBatis 
{
	String insertData="insert into studenttable(studentid,studentname,dob,gender,phone,education)"+
			"values(#{studentid},#{studentname},#{dob},#{gender},#{phone},#{education})";
	String deleteData="delete from studenttable where studentid=#{studentid}";
	String updateData="update studenttable set studentname=#{studentname},dob=#{dob},gender=#{gender},phone=#{phone},education=#{education}"+"where studentid=#{studentid}";
	String selectOne="select * from studenttable where studentid=#{studentid}";
	String selectAll="select * from studenttable";
	String search="select * from studenttable where studentid=#{studentid} or studentname=#{studentname}";
	
	@Insert(insertData)
	int insertData(StudentRequestDTO dto);
	@Update(updateData)
	int updateData(StudentRequestDTO dto);
	
	@Delete(deleteData)
	int deleteData(StudentRequestDTO dto);
	
	@Select(selectAll)
	@Results(value ={
			@Result(column ="studentid", property="studentid"),
			@Result(column ="studentname", property="studentname"),
			@Result(column ="dob", property="dob"),
			@Result(column ="gender", property="gender"),
			@Result(column ="phone", property="phone"),
			@Result(column ="education", property="education")
		
	})
	ArrayList<StudentResponseDTO> selectAll();
	
	@Select(selectOne)
	@Results(value = {
			@Result(column ="studentid", property="studentid"),
			@Result(column ="studentname", property="studentname"),
			@Result(column ="dob", property="dob"),
			@Result(column ="gender", property="gender"),
			@Result(column ="phone", property="phone"),
			@Result(column ="education", property="education")
	})
	StudentResponseDTO selectOne(StudentRequestDTO dto);
	
	@Select(search)
	@Results(value ={
			@Result(column ="studentid", property="studentid"),
			@Result(column ="studentname", property="studentname"),
			@Result(column ="dob", property="dob"), 
			@Result(column ="gender", property="gender"),
			@Result(column ="phone", property="phone"),
			@Result(column ="education", property="education")
		
	})
	List<StudentResponseDTO> search(StudentRequestDTO dto);
	
}
