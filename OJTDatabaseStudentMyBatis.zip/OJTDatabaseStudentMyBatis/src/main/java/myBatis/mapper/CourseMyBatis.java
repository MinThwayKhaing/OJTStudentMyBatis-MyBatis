package myBatis.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import DTO.CourseRequestDTO;
import DTO.CourseResponseDTO;
import DTO.UserResponseDTO;




public interface CourseMyBatis 
{
	
	String insertData ="insert into coursetable(courseid,coursename)"+
			"values(#{courseid},#{coursename})";
	String selectAll="select * from coursetable";
	
	@Insert(insertData)
	int insert(CourseRequestDTO dto);
	
	@Select(selectAll)
	@Results(value ={
		@Result(column ="courseid", property="courseid"),
		@Result(column ="coursename", property="coursename"),
		
	})
	ArrayList<CourseResponseDTO> selectAll();
}