package DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import DTO.CourseRequestDTO;
import DTO.CourseResponseDTO;
import myBatis.mapper.CourseMyBatis;

@Service("courseDAO")
public class CourseDAO 
{
	@Autowired
	CourseMyBatis courseMyBatis;
	public int insert(CourseRequestDTO dto) {
		// TODO Auto-generated method stub
		return courseMyBatis.insert(dto);
	}
	
	public List<CourseResponseDTO> selectAll() {
		// TODO Auto-generated method stub
		System.out.print(courseMyBatis.selectAll());
		return courseMyBatis.selectAll();
	}

}
