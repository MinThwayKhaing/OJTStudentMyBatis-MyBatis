package DAO;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import DTO.UserRequestDTO;
import DTO.UserResponseDTO;
import Model.LoginBean;

import myBatis.mapper.UserMyBatis;



@Service("userDAO")
public class UserDAO 
{
	@Autowired
	UserMyBatis userMyBatis;
	public List<UserResponseDTO> Login(LoginBean bean) {
		// TODO Auto-generated method stub
		
		return userMyBatis.Login(bean);
	}
	public int insert(UserRequestDTO dto) {
		// TODO Auto-generated method stub
	return userMyBatis.insertData(dto);
	}
	public int update(UserRequestDTO dto) {
		// TODO Auto-generated method stub
		
		return userMyBatis.updateData(dto);
	}
	public int delete(UserRequestDTO dto) {
		// TODO Auto-generated method stub
		return userMyBatis.deleteData(dto);
	}
	public List<UserResponseDTO> selectAll() {
		// TODO Auto-generated method stub
		System.out.print(userMyBatis.selectAll());
		return userMyBatis.selectAll();
	}


	public UserResponseDTO selectOne(UserRequestDTO dto) {
		// TODO Auto-generated method stub
		return userMyBatis.selectOne(dto);
	}
	public List<UserResponseDTO> search(UserRequestDTO dto) {
		// TODO Auto-generated method stub
		
		return userMyBatis.search(dto);
	}
		

}