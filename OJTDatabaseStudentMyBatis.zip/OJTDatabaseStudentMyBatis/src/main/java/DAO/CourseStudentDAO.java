package DAO;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import DTO.CourseStudentRequestDTO;
import DTO.CourseStudentResponseDTO;
import myBatis.mapper.CourseStudent;

@Service("courseStudentDAO")
public class CourseStudentDAO 
{
	@Autowired
	@Qualifier("courseStudentMyBatis")
	CourseStudent courseStudent;
	
	public int insert(CourseStudentRequestDTO dto) 
	{
		// TODO Auto-generated method stub
	return courseStudent.insertData(dto);
	}
	public int delete(CourseStudentRequestDTO dto) 
	{
		// TODO Auto-generated method stub
	return courseStudent.deleteData(dto);
	}
	public ArrayList<String> selectOne(String id) 
	{
		// TODO Auto-generated method stub
		return courseStudent.selectOne(id);
	}
	public List<CourseStudentResponseDTO> search(CourseStudentRequestDTO dto) {
		// TODO Auto-generated method stub
		
		return courseStudent.search(dto);
	}
}
