package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import DTO.CourseRequestDTO;
import DTO.CourseResponseDTO;
import DTO.StudentRequestDTO;
import DTO.StudentResponseDTO;
import DTO.UserRequestDTO;
import DTO.UserResponseDTO;
import Model.LoginBean;
import myBatis.mapper.StudentMyBatis;
import myBatis.mapper.UserMyBatis;
@Service("studentDAO")
public class StudentDAO 
{
	@Autowired
	@Qualifier("studentMyBatis")
	StudentMyBatis studentMyBatis;
	
	public int insert(StudentRequestDTO dto) {
		// TODO Auto-generated method stub
	return studentMyBatis.insertData(dto);
	}
	public int update(StudentRequestDTO dto) {
		// TODO Auto-generated method stub
		
		return studentMyBatis.updateData(dto);
	}
	public int delete(StudentRequestDTO dto) {
		// TODO Auto-generated method stub
		return studentMyBatis.deleteData(dto);
	}
	public List<StudentResponseDTO> selectAll() {
		// TODO Auto-generated method stub
		System.out.print(studentMyBatis.selectAll());
		return studentMyBatis.selectAll();
	}


	public StudentResponseDTO selectOne(StudentRequestDTO dto) {
		// TODO Auto-generated method stub
		return studentMyBatis.selectOne(dto);
	}
	public List<StudentResponseDTO> search(StudentRequestDTO dto) {
		// TODO Auto-generated method stub
		
		return studentMyBatis.search(dto);
	}

}
